from odoo import models


class MisKpiDataTestItem(models.Model):

    _name = "mis.kpi.data.test.item"
    _inherit = "mis.kpi.data"
    _description = "MIS Kpi Data test item"
