* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Laetitia Gangloff <laetitia.gangloff@acsone.eu>
* Adrien Peiffer <adrien.peiffer@acsone.eu>
* Alexis de Lattre <alexis.delattre@akretion.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Jordi Ballester <jordi.ballester@eficent.com>
* Thomas Binsfeld <thomas.binsfeld@gmail.com>
* Giovanni Capalbo <giovanni@therp.nl>
* Marco Calcagni <mcalcagni@dinamicheaziendali.it>
* Sébastien Beau <sebastien.beau@akretion.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Luc De Meyer <luc.demeyer@noviat.com>
* Benjamin Willig <benjamin.willig@acsone.eu>
* Martronic SA <info@martronic.ch>
* nicomacr <nmr@adhoc.com.ar>
* Juan Jose Scarafia <jjs@adhoc.com.ar>
* Richard deMeester <richard@willowit.com.au>
* Eric Caudal <eric.caudal@elico-corp.com>
* Andrea Stirpe <a.stirpe@onestein.nl>
* Maxence Groine <mgroine@fiefmanage.ch>
* Arnaud Pineux <arnaud.pineux@acsone.eu>
* Ernesto Tejeda <ernesto.tejeda@tecnativa.com>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Alexey Pelykh <alexey.pelykh@corphub.eu>
* Jairo Llopis (https://www.moduon.team/)
* Dzung Tran <dungtd@trobz.com>
* Hoang Diep <hoang@trobz.com>
